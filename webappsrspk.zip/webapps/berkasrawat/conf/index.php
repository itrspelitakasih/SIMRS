<?php
    exit(header("Location:../index.php"));
?>